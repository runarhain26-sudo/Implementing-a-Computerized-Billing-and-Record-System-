/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author rhain
 */
public class ownerregister extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ownerregister.class.getName());

    /**
     * Creates new form ownerregister
     */
    public ownerregister() {
      initComponents();
    q.setEditable(false); // make slot number read-only
    generateSlotNumber(); // auto-generate next slot number
    s.setEditable(false); // Prevent typing
    setCurrentDate();     // Auto-fill today's date

    // Restrict contact number input to numbers only (11 digits max)
    d.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            char c = evt.getKeyChar();
            if (!Character.isDigit(c)) evt.consume(); // only numbers
            if (d.getText().length() >= 11) evt.consume(); // max 11 digits
        }
    });
   
   



    
    w.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            char c = evt.getKeyChar();
            if (!Character.isLetter(c) && !Character.isWhitespace(c)) {
                evt.consume();
            }
        }
    });
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        name = new javax.swing.JLabel();
        contact = new javax.swing.JLabel();
        email = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        costumer = new javax.swing.JLabel();
        w = new javax.swing.JTextField();
        q = new javax.swing.JTextField();
        s = new javax.swing.JTextField();
        a = new javax.swing.JTextField();
        d = new javax.swing.JTextField();
        name1 = new javax.swing.JLabel();
        q1 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 0, 60)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("CUSTOMER REGISTER");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, -1, -1));

        jPanel2.setBackground(new java.awt.Color(0, 153, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3));
        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        name.setFont(new java.awt.Font("Segoe UI Black", 0, 30)); // NOI18N
        name.setForeground(new java.awt.Color(255, 255, 255));
        name.setText("Address:");
        jPanel2.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, -1, -1));

        contact.setFont(new java.awt.Font("Segoe UI Black", 0, 30)); // NOI18N
        contact.setForeground(new java.awt.Color(255, 255, 255));
        contact.setText("Contact no.:");
        jPanel2.add(contact, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, -1, -1));

        email.setFont(new java.awt.Font("Segoe UI Black", 0, 30)); // NOI18N
        email.setForeground(new java.awt.Color(255, 255, 255));
        email.setText("E-mail:");
        jPanel2.add(email, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));

        date.setFont(new java.awt.Font("Segoe UI Black", 0, 30)); // NOI18N
        date.setForeground(new java.awt.Color(255, 255, 255));
        date.setText("Date of register:");
        jPanel2.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, -1, -1));

        costumer.setFont(new java.awt.Font("Segoe UI Black", 0, 30)); // NOI18N
        costumer.setForeground(new java.awt.Color(255, 255, 255));
        costumer.setText("Slot num:");
        jPanel2.add(costumer, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, -1, -1));

        w.setForeground(new java.awt.Color(0, 153, 204));
        w.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                wActionPerformed(evt);
            }
        });
        jPanel2.add(w, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 50, 570, 48));

        q.setForeground(new java.awt.Color(0, 153, 204));
        jPanel2.add(q, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 410, 560, 48));

        s.setForeground(new java.awt.Color(0, 153, 204));
        jPanel2.add(s, new org.netbeans.lib.awtextra.AbsoluteConstraints(285, 260, 560, 48));

        a.setForeground(new java.awt.Color(0, 153, 204));
        jPanel2.add(a, new org.netbeans.lib.awtextra.AbsoluteConstraints(285, 190, 560, 48));

        d.setForeground(new java.awt.Color(0, 153, 204));
        jPanel2.add(d, new org.netbeans.lib.awtextra.AbsoluteConstraints(285, 120, 560, 48));

        name1.setFont(new java.awt.Font("Segoe UI Black", 0, 30)); // NOI18N
        name1.setForeground(new java.awt.Color(255, 255, 255));
        name1.setText("Name:");
        jPanel2.add(name1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, -1, -1));

        q1.setForeground(new java.awt.Color(0, 153, 204));
        jPanel2.add(q1, new org.netbeans.lib.awtextra.AbsoluteConstraints(285, 330, 560, 48));

        jButton5.setFont(new java.awt.Font("Segoe UI Black", 0, 30)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 153, 255));
        jButton5.setText("ADD");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 440, 210, 60));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 110, 880, 500));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/download-removebg-preview (1).png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 240, 130));

        jButton4.setBackground(new java.awt.Color(0, 204, 204));
        jButton4.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("REGISTER");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 220, 70));

        jButton6.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jButton6.setForeground(new java.awt.Color(0, 153, 255));
        jButton6.setText("BACK");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 560, 220, 70));

        jButton3.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 153, 255));
        jButton3.setText("LIST OF CUSTOMER ");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 220, 70));

        jButton7.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jButton7.setForeground(new java.awt.Color(0, 153, 255));
        jButton7.setText("EMPLOYEE");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 220, 70));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1424, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 872, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void wActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_wActionPerformed
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_wActionPerformed
private void setCurrentDate() {
    java.time.LocalDate today = java.time.LocalDate.now();
    java.time.format.DateTimeFormatter format = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");
    s.setText(today.format(format));
}

    private void generateSlotNumber() {
    try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbregister", "root", "")) {
            PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM clientdata");
            java.sql.ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int nextSlot = rs.getInt(1) + 1;
                q.setText(String.valueOf(nextSlot));
            } else {
                q.setText("1");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        
    String name = w.getText().trim();
    String contact = d.getText().trim();
    String gmail = a.getText().trim();
    String date = s.getText().trim();
    String slot = q.getText().trim();

    // 1️⃣ EMPTY FIELD CHECK
if (name.isEmpty() || contact.isEmpty() || gmail.isEmpty() || date.isEmpty()) {
    JOptionPane.showMessageDialog(this, "⚠️ Please fill in all fields!");
    return;
}

// 2️⃣ EMAIL VALIDATION (MUST BE OUTSIDE)
String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
if (!gmail.matches(emailRegex)) {
    JOptionPane.showMessageDialog(
        this,
        "⚠️ Invalid email format!\nExample: sample@gmail.com",
        "Invalid Email",
        JOptionPane.ERROR_MESSAGE
    );
    a.requestFocus();
    return;
}

// 3️⃣ CONTACT NUMBER CHECK
if (contact.length() != 11) {
    JOptionPane.showMessageDialog(this, "⚠️ Contact number must be exactly 11 digits!");
    return;

    }

    String url = "jdbc:mysql://localhost:3306/dbregister?zeroDateTimeBehavior=CONVERT_TO_NULL";
    String user = "root";
    String password = "";

    try (Connection conn = DriverManager.getConnection(url, user, password)) {
        String sql = "INSERT INTO clientdata "
    + "(Name, ContactNumber, Gmail, DateOfRegister, SlotNum, "
    + "due_of_last_pay, due_date, status, amount_paid) "
    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

PreparedStatement pstmt = conn.prepareStatement(sql);

pstmt.setString(1, name);
pstmt.setString(2, contact);
pstmt.setString(3, gmail);
pstmt.setString(4, date);
pstmt.setString(5, slot);

// NEW FIELDS:
pstmt.setString(6, "");            
pstmt.setString(7, date);          
pstmt.setString(8, "inactive");   
pstmt.setDouble(9, 0.00);       
        pstmt.executeUpdate();
        JOptionPane.showMessageDialog(this, "✅ Data inserted successfully!");

        // Auto update next slot number
        generateSlotNumber();

        // Clear fields
        w.setText("");
        d.setText("");
        a.setText("");
        s.setText("");

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "❌ Database error: " + ex.getMessage());
    }
    
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        ownerregister registerFrame=new ownerregister();
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setVisible(true);        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        ownerhome registerFrame=new ownerhome();
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setVisible(true);
        dispose(); // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         dueowner registerFrame=new dueowner();
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setVisible(true);
        dispose(); // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        DBConnection registerFrame = new DBConnection(); // open another form
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setVisible(true);
        dispose();
        dispose();
    }//GEN-LAST:event_jButton7ActionPerformed


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ownerregister().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField a;
    private javax.swing.JLabel contact;
    private javax.swing.JLabel costumer;
    private javax.swing.JTextField d;
    private javax.swing.JLabel date;
    private javax.swing.JLabel email;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel name;
    private javax.swing.JLabel name1;
    private javax.swing.JTextField q;
    private javax.swing.JTextField q1;
    private javax.swing.JTextField s;
    private javax.swing.JTextField w;
    // End of variables declaration//GEN-END:variables
}
