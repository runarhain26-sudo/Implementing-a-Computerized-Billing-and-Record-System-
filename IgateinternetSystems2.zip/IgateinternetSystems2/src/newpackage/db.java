package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author rhain
 */
public class db {
    public static Connection mycon() {
        Connection con = null;

        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");

            
            con = DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1:3306/register",
                    "root", 
                    "" 
            );

        } catch (ClassNotFoundException e) {
            System.err.println("Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("Database connection error: " + e.getMessage());
        }

        return con;
    }
}
