package newpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 * Comprehensive Activity Log / Audit Trail Viewer
 * Tracks all system activities: Login, Register, Payment, Edit, Delete
 * Displays: Date/Time, Action Type, Slot #, Customer, Performed By, Status, Details
 * @author rhain
 */
public class History extends javax.swing.JFrame {
    
   private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(History.class.getName());
    private TableRowSorter<DefaultTableModel> sorter;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnRefresh;
    
     /**
     * Creates new form History
     */
    public History() {
        initComponents();
        createHistoryTable();
        loadHistoryData();
        setupTableSorter();
    }


   private void createHistoryTable() {
        String url = "jdbc:mysql://localhost:3306/dbregister?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String user = "root";
        String password = "";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String createTableSQL = "CREATE TABLE IF NOT EXISTS history ("
                + "id INT AUTO_INCREMENT PRIMARY KEY, "
                + "action_type VARCHAR(50) NOT NULL, "
                + "slot_num VARCHAR(20), "
                + "customer_name VARCHAR(100), "
                + "performed_by VARCHAR(100), "
                + "action_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, "
                + "details TEXT, "
                + "status VARCHAR(20) DEFAULT 'SUCCESS', "
                + "INDEX idx_action_date (action_date DESC), "
                + "INDEX idx_performed_by (performed_by), "
                + "INDEX idx_action_type (action_type)"
                + ")";
            
            PreparedStatement pstmt = conn.prepareStatement(createTableSQL);
            pstmt.executeUpdate();
            
        } catch (Exception ex) {
            logger.log(java.util.logging.Level.SEVERE, "History table creation error", ex);
        }
    }
    
     private void loadHistoryData() {
       String url = "jdbc:mysql://localhost:3306/dbregister?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String user = "root";
        String password = "";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            
            String sql = "SELECT action_date, action_type, slot_num, customer_name, performed_by, "
                       + "COALESCE(status, 'SUCCESS') as status, details "
                       + "FROM history "
                       + "WHERE action_type IN ('LOGIN', 'REGISTER', 'PAYMENT', 'EDIT', 'DELETE', 'PRINT_RECEIPT', 'EMPLOYEE_REGISTRATION') "
                       + "ORDER BY action_date DESC LIMIT 500";
            
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            while (rs.next()) {
                Object[] row = {
                    rs.getTimestamp("action_date") != null ? 
                        dateFormat.format(rs.getTimestamp("action_date")) : "N/A",
                    rs.getString("action_type") != null ? rs.getString("action_type") : "UNKNOWN",
                    rs.getString("slot_num") != null ? rs.getString("slot_num") : "—",
                    rs.getString("customer_name") != null ? rs.getString("customer_name") : "—",
                    rs.getString("performed_by") != null ? rs.getString("performed_by") : "System",
                    rs.getString("status") != null ? rs.getString("status") : "SUCCESS",
                    rs.getString("details") != null ? rs.getString("details") : ""
                };
                model.addRow(row);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "❌ Error loading history: " + ex.getMessage());
            logger.log(java.util.logging.Level.SEVERE, "Error loading history", ex);
        }
    }

    private void setupTableSorter() {
         DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        sorter = new TableRowSorter<>(model);
        jTable1.setRowSorter(sorter);
    }
    
 public static void logLogin(String performedBy, String userRole, String status, String details) {
        logHistory("LOGIN", null, null, performedBy, status, "User Role: " + userRole + " | " + details);
    }
public static void logEmployeeRegistration(String employeeName, String contact, String performedBy, String details) {
    logHistory("EMPLOYEE_REGISTRATION", null, null, performedBy, "SUCCESS", 
               "New Employee Created | Name: " + employeeName + " | Contact: " + contact + " | " + details);
}
    public static void logLogout(String performedBy, String details) {
        logHistory("LOGOUT", null, null, performedBy, "SUCCESS", details);
    }

     public static void logRegister(String slotNum, String customerName, String performedBy, String details) {
        logHistory("REGISTER", slotNum, customerName, performedBy, "SUCCESS", "New customer registered | " + details);
    }

    public static void logPayment(String slotNum, String customerName, String performedBy, String amount, String details) {
        logHistory("PAYMENT", slotNum, customerName, performedBy, "SUCCESS", 
                   "Amount: ₱" + amount + " | " + details);
    }

   public static void logEdit(String slotNum, String customerName, String performedBy, String fields, String details) {
        logHistory("EDIT", slotNum, customerName, performedBy, "SUCCESS", 
                   "Fields Updated: " + fields + " | " + details);
    }

    public static void logDelete(String slotNum, String customerName, String performedBy, String details) {
        logHistory("DELETE", slotNum, customerName, performedBy, "SUCCESS", 
                   "Customer deleted | " + details);
    }

    public static void logSearch(String performedBy, String searchCriteria, String resultsCount) {
        logHistory("SEARCH", null, null, performedBy, "SUCCESS", 
                   "Criteria: " + searchCriteria + " | Results: " + resultsCount);
    }
    
    public static void logError(String actionType, String performedBy, String errorMessage) {
        logHistory(actionType, null, null, performedBy, "ERROR", "Error: " + errorMessage);
    }
    
    public static void logHistory(String actionType, String slotNum, String customerName, 
                                   String performedBy, String status, String details) {
        String url = "jdbc:mysql://localhost:3306/dbregister?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String user = "root";
        String password = "";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            String sql = "INSERT INTO history (action_type, slot_num, customer_name, performed_by, action_date, status, details) "
                       + "VALUES (?, ?, ?, ?, NOW(), ?, ?)";
            
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, actionType);
            pstmt.setString(2, slotNum);
            pstmt.setString(3, customerName);
            pstmt.setString(4, performedBy);
            pstmt.setString(5, status);
            pstmt.setString(6, details);
            
            pstmt.executeUpdate();
            
        } catch (Exception ex) {
            System.err.println("Error logging history: " + ex.getMessage());
            logger.log(java.util.logging.Level.WARNING, "History logging failed", ex);
        }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 0, 60)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("REGISTER FOR EMPLOYEE");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, -1, -1));

        jPanel2.setBackground(new java.awt.Color(0, 153, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3));
        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Date/Time", "Action Type", "Slot #", "Customer", "Performed By", "Status", "Details"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setResizable(false);
            jTable1.getColumnModel().getColumn(6).setResizable(false);
        }

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 880, 500));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 110, 880, 500));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/download-removebg-preview (1).png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 240, 130));

        jButton4.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(0, 153, 255));
        jButton4.setText("REGISTER");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 220, 70));

        jButton1.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 153, 255));
        jButton1.setText("LIST OF CUSTOMER ");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 220, 70));

        jButton6.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jButton6.setForeground(new java.awt.Color(0, 153, 255));
        jButton6.setText("BACK");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 560, 220, 70));

        jButton3.setBackground(new java.awt.Color(0, 204, 204));
        jButton3.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("History");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 480, 220, 70));

        jButton5.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jButton5.setForeground(new java.awt.Color(0, 153, 204));
        jButton5.setText("Payment");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 220, 70));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1424, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 872, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
          adminhome registerFrame = new adminhome();
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         adminlist registerFrame = new adminlist();
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
          ownerhome registerFrame = new ownerhome();
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      History registerFrame = new History();
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
         adminpayment registerFrame = new adminpayment();
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {                                          
         
        btnSearchActionPerformed(evt);
    }                                         

    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {                                          
        String text = txtSearch.getText().trim();
        if (text.length() == 0) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
        }
    }                                         

     private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {                                           
         loadHistoryData();
        txtSearch.setText("");
        JOptionPane.showMessageDialog(this, "✅ Activity log refreshed!", "Refresh", JOptionPane.INFORMATION_MESSAGE);
    }                                             

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        java.awt.EventQueue.invokeLater(() -> new History().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
